const CACHE_NAME = 'ar-scanner-pro-v1';
// List of assets to precache for offline support.  These should include
// your core HTML, JS modules, styles, translations and images.  See
// MDN's Cache API documentation for details on cache.addAll()【817621886742007†L125-L132】.
// When serving over HTTP(S) these URLs can be absolute ("/index.html"), but
// when the app is opened from the filesystem (file:// scheme) absolute
// requests point to the root of the OS and fail.  Use relative paths so
// that fetch() resolves against the service worker's scope, which works for
// both cases.  Do not include a leading slash.
const LOCAL_ASSETS = [
  '.',
  'index.html',
  'manifest.json',
  'js/modules/firebase-service.js',
  'js/modules/localization.js',
  'js/modules/theme-manager.js',
  'js/modules/ar-scanner.js',
  'js/modules/gallery-manager.js',
  'js/modules/ui-controller.js',
  'js/services/storage-service.js',
  'js/utils/performance.js',
  'js/utils/error-handler.js',
  'locales/en.json',
  'locales/ar.json',
  'assets/images/logo.png',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png'
];

// Install event: cache core assets so the app can work offline.  The Cache
// interface's addAll() method takes an array of URLs, retrieves them, and
// stores the responses in the cache【817621886742007†L125-L133】.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(LOCAL_ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Fetch event: serve requests from cache when possible, otherwise fall back
// to the network.  External resources such as Firebase scripts are
// bypassed so that they always load the latest version from the network.
self.addEventListener('fetch', (event) => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;
  const url = event.request.url;
  // Bypass caching for external resources
  if (url.includes('firebase') || url.includes('googleapis') || url.includes('cdn') || url.includes('gstatic') || url.includes('unpkg.com')) {
    event.respondWith(fetch(event.request));
    return;
  }
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request).then((response) => {
        // If the request is for a local asset and the response is OK, cache it
        if (response && response.ok && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});

// Activate event: remove old caches when a new version is activated.
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});