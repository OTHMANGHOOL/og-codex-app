// StorageService provides a simple abstraction for storing and retrieving
// scans.  In a production environment this would interface with
// Firebase Firestore; here it uses an in‑memory object so that the app
// functions offline without configuration.

const _userScans = {};

class StorageService {
  async getUserScans(userId) {
    try {
      const scans = _userScans[userId] || [];
      // return a copy sorted by createdAt descending
      return scans.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } catch (error) {
      console.error('Failed to load scans:', error);
      return [];
    }
  }

  async addUserScan(userId, scan) {
    if (!_userScans[userId]) {
      _userScans[userId] = [];
    }
    _userScans[userId].unshift(scan);
    return Promise.resolve();
  }
}

export const storageService = new StorageService();