// Utility for displaying toast notifications.  Depending on the type
// (info, success or error) the toast will have a different colour.  It
// automatically disappears after a few seconds.

export function showToast(message, type = 'info') {
  // Create toast element if it doesn't exist
  let toast = document.getElementById('globalToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'globalToast';
    toast.className = 'fixed bottom-4 right-4 p-4 rounded-lg shadow-lg z-50 max-w-xs';
    document.body.appendChild(toast);
  }
  // Set message and styling based on type
  toast.textContent = message;
  toast.className = `fixed bottom-4 right-4 p-4 rounded-lg shadow-lg z-50 max-w-xs transition-opacity duration-300 ${
    type === 'error' ? 'bg-red-500 text-white' :
    type === 'success' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white'
  }`;
  // Reset opacity for fade-in
  toast.style.opacity = '1';
  // Auto hide after 3 seconds
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}