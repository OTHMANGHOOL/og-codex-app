// Utility functions for performance optimisations.  Provides a helper for
// lazily loading <model-viewer> elements and a simple throttle implementation.

// Waits for the <model-viewer> element to finish loading before resolving.
export function lazyLoadModel(modelViewer) {
  return new Promise((resolve) => {
    // If already loaded, resolve immediately
    if (modelViewer.loaded) {
      resolve();
    } else {
      const onLoad = () => {
        modelViewer.removeEventListener('load', onLoad);
        resolve();
      };
      modelViewer.addEventListener('load', onLoad);
    }
  });
}

// Creates a throttled version of a function that will only run at most once
// per `limit` milliseconds.  Useful for scroll or resize handlers.
export function throttle(func, limit = 100) {
  let lastFunc;
  let lastRan;
  return function throttled() {
    const context = this;
    const args = arguments;
    if (!lastRan) {
      func.apply(context, args);
      lastRan = Date.now();
    } else {
      clearTimeout(lastFunc);
      lastFunc = setTimeout(function execute() {
        if ((Date.now() - lastRan) >= limit) {
          func.apply(context, args);
          lastRan = Date.now();
        }
      }, limit - (Date.now() - lastRan));
    }
  };
}