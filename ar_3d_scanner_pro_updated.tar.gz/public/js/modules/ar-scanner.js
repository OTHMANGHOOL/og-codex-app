import { db, storage, auth, ref, uploadBytes, getDownloadURL, collection, addDoc, serverTimestamp } from './firebase-service.js';
import { galleryManager } from './gallery-manager.js';
import { storageService } from '../services/storage-service.js';
import { showToast } from '../utils/error-handler.js';
// ARScanner simulates a 3D scanning process.  It updates a progress bar and,
// when complete, generates a dummy GLB blob, stores it (locally and in
// Firebase if available) and refreshes the gallery.

class ARScanner {
  constructor() {
    this.isScanning = false;
    this.scanData = [];
    this.captureInterval = null;
    // Initialise scanning environment
    this.init();
  }

  async init() {
    // Try to access the camera.  In this simplified demo we don't render
    // the video feed, but requesting permission allows the user to grant
    // access if desired.  If access fails we log a warning; the scanning
    // simulation will still work.
    try {
      await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    } catch (err) {
      console.warn('Camera access failed or was denied:', err);
    }
  }

  startScan() {
    if (this.isScanning) return;
    this.isScanning = true;
    this.scanData = [];
    // Show scanning UI
    document.getElementById('scanProgress').classList.remove('hidden');
    const startBtn = document.getElementById('startScanBtn');
    startBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin mr-2"></i><span data-i18n="scanningText">Scanning...</span>';
    // Disable the button during scanning
    startBtn.disabled = true;
    // Start simulated capture loop
    this.captureInterval = setInterval(() => {
      this.captureFrame();
    }, 300);
  }

  captureFrame() {
    const progress = this.scanData.length;
    if (progress < 100) {
      this.scanData.push(progress);
      document.getElementById('scanProgressBar').style.width = `${progress}%`;
    } else {
      this.stopScan();
    }
  }

  async stopScan() {
    if (!this.isScanning) return;
    clearInterval(this.captureInterval);
    this.isScanning = false;
    try {
      const glbBlob = await this.processScanData();
      await this.saveScan(glbBlob);
      showToast('Scan completed successfully!', 'success');
    } catch (error) {
      console.error('Scan processing failed:', error);
      showToast('Scan failed', 'error');
    } finally {
      this.resetScanUI();
    }
  }

  async processScanData() {
    // In this demo we simply return a small JSON payload as a binary blob.  A
    // real implementation would process point clouds or video frames into
    // a 3D model.
    const data = { sample: '3D model data', timestamp: Date.now() };
    return new Blob([JSON.stringify(data)], { type: 'model/gltf-binary' });
  }

  async saveScan(glbBlob) {
    // Determine the user ID from the auth object (real or dummy)
    const userId = auth && auth.currentUser ? auth.currentUser.uid : 'guest';
    const filename = `scan_${Date.now()}.glb`;
    let downloadURL = '';
    // Try to upload to Firebase Storage if available
    if (storage && ref && uploadBytes && getDownloadURL) {
      try {
        const storageRef = ref(storage, `scans/${userId}/${filename}`);
        const snapshot = await uploadBytes(storageRef, glbBlob);
        downloadURL = await getDownloadURL(snapshot.ref);
      } catch (err) {
        console.warn('Failed to upload scan to Firebase Storage:', err);
      }
    }
    // Try to add a record in Firestore if available
    if (db && collection && addDoc && serverTimestamp) {
      try {
        await addDoc(collection(db, 'scans'), {
          userId,
          createdAt: serverTimestamp(),
          name: `Scan ${new Date().toLocaleDateString()}`,
          url: downloadURL,
          size: `${(glbBlob.size / 1024 / 1024).toFixed(1)} MB`,
          views: 0,
          downloads: 0,
          shares: 0
        });
      } catch (err) {
        console.warn('Failed to save scan to Firestore:', err);
      }
    }
    // Always save a local record so the gallery can display the scan
    await storageService.addUserScan(userId, {
      id: filename,
      createdAt: Date.now(),
      name: `Scan ${new Date().toLocaleDateString()}`,
      url: downloadURL || URL.createObjectURL(glbBlob),
      size: `${(glbBlob.size / 1024 / 1024).toFixed(1)} MB`
    });
    // Refresh the gallery
    galleryManager.loadUserScans(userId);
  }

  resetScanUI() {
    const startBtn = document.getElementById('startScanBtn');
    const progressBar = document.getElementById('scanProgress');
    startBtn.disabled = false;
    startBtn.innerHTML = '<i class="fas fa-camera mr-2"></i><span data-i18n="scanButtonText">Start Scanning</span>';
    progressBar.classList.add('hidden');
    document.getElementById('scanProgressBar').style.width = '0%';
  }
}

export const arScanner = new ARScanner();