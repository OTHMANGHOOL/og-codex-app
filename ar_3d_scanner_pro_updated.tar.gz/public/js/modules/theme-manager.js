// Theme manager toggles between light and dark modes and persists the
// user's preference in localStorage.  It also synchronises the toggle
// checkbox state with the current theme.

class ThemeManager {
  constructor() {
    this.currentTheme = this.getSavedTheme();
    this.applyTheme();
  }

  getSavedTheme() {
    return localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  }

  setTheme(theme) {
    this.currentTheme = theme;
    localStorage.setItem('theme', theme);
    this.applyTheme();
  }

  applyTheme() {
    if (this.currentTheme === 'dark') {
      document.documentElement.classList.add('dark');
      const toggle = document.getElementById('themeToggle');
      if (toggle) toggle.checked = true;
    } else {
      document.documentElement.classList.remove('dark');
      const toggle = document.getElementById('themeToggle');
      if (toggle) toggle.checked = false;
    }
  }
}

export const themeManager = new ThemeManager();