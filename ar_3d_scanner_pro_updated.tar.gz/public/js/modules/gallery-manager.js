import { lazyLoadModel } from '../utils/performance.js';
import { showToast } from '../utils/error-handler.js';
import { storageService } from '../services/storage-service.js';

// GalleryManager is responsible for loading a user's scans from storage
// and rendering them into a responsive grid.  Each item in the gallery
// includes a placeholder thumbnail and a model-viewer element that is
// lazily loaded when scrolled into view.  Download functionality is
// implemented for locally stored scans.
class GalleryManager {
  constructor() {
    this.scans = [];
    this.observer = new IntersectionObserver(this.handleIntersect.bind(this), {
      rootMargin: '100px',
      threshold: 0.01
    });
  }

  async loadUserScans(userId) {
    try {
      this.showLoading();
      this.scans = await storageService.getUserScans(userId);
      this.renderGallery();
    } catch (error) {
      showToast('Failed to load gallery', 'error');
    } finally {
      this.hideLoading();
    }
  }

  showLoading() {
    // Optionally implement a loading indicator here
  }

  hideLoading() {
    // Hide any loading indicator here
  }

  renderGallery() {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;
    grid.innerHTML = '';
    this.scans.forEach((scan) => {
      const item = this.createScanItem(scan);
      grid.appendChild(item);
      this.observer.observe(item);
    });
    this.setupGalleryEvents();
  }

  createScanItem(scan) {
    const item = document.createElement('div');
    item.className = 'scan-item bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md';
    item.dataset.scanId = scan.id;
    item.innerHTML = `
      <div class="scan-thumbnail">
        <div class="model-placeholder bg-gray-100 dark:bg-gray-700 flex items-center justify-center h-40">
          <i class="fas fa-cube text-3xl text-gray-300"></i>
        </div>
        <model-viewer 
          class="hidden"
          loading="lazy"
          src="${scan.url || ''}"
          alt="${scan.name || ''}"
          reveal="auto"
          ar
          camera-controls
          disable-zoom
          auto-rotate-delay="3000"
          style="width:100%;height:100%">
        </model-viewer>
      </div>
      <div class="scan-meta p-3">
        <h3 class="font-semibold truncate">${scan.name || 'Untitled'}</h3>
        <div class="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-1">
          <span>${scan.createdAt ? new Date(scan.createdAt).toLocaleDateString() : ''}</span>
          <span>${scan.size || ''}</span>
        </div>
        <div class="flex justify-between mt-2">
          <button class="view-3d text-blue-500" title="View in 3D">
            <i class="fas fa-cube"></i>
          </button>
          <button class="download text-blue-500" title="Download">
            <i class="fas fa-download"></i>
          </button>
          <button class="share text-blue-500" title="Share">
            <i class="fas fa-share-alt"></i>
          </button>
        </div>
      </div>
    `;
    return item;
  }

  handleIntersect(entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const container = entry.target;
        const placeholder = container.querySelector('.model-placeholder');
        const modelViewer = container.querySelector('model-viewer');
        if (modelViewer && placeholder) {
          lazyLoadModel(modelViewer).then(() => {
            placeholder.classList.add('hidden');
            modelViewer.classList.remove('hidden');
          });
          this.observer.unobserve(container);
        }
      }
    });
  }

  setupGalleryEvents() {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;
    grid.addEventListener('click', (e) => {
      const scanItem = e.target.closest('.scan-item');
      if (!scanItem) return;
      const scanId = scanItem.dataset.scanId;
      if (e.target.closest('.download')) {
        this.downloadScan(scanId);
      } else if (e.target.closest('.view-3d')) {
        this.viewScan3D(scanId);
      } else if (e.target.closest('.share')) {
        this.shareScan(scanId);
      }
    });
  }

  async downloadScan(scanId) {
    const scan = this.scans.find((s) => s.id === scanId);
    if (!scan) return;
    try {
      const response = await fetch(scan.url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `scan_${scanId}.glb`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      showToast('Download started', 'success');
    } catch (error) {
      showToast('Download failed', 'error');
    }
  }

  viewScan3D(scanId) {
    // For a real application you might open a dedicated viewer.  Here
    // we simply switch to the share tab and display a QR code.
    document.getElementById('navShare').click();
  }

  shareScan(scanId) {
    // This could invoke a share API or copy a link to clipboard.
    showToast('Share functionality not implemented yet', 'info');
  }
}

export const galleryManager = new GalleryManager();