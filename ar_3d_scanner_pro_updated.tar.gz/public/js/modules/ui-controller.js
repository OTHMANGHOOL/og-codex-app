import { localization } from './localization.js';
import { themeManager } from './theme-manager.js';
import { arScanner } from './ar-scanner.js';
import { galleryManager } from './gallery-manager.js';
import { auth } from './firebase-service.js';

// UIController wires up user interactions: language and theme toggles,
// navigation, and scan button actions.  It listens for authentication
// changes so that the gallery can be refreshed when the user signs in.

class UIController {
  constructor() {
    this.currentView = 'scanner';
    this.registerEvents();
    this.setupAuthListener();
  }

  setupAuthListener() {
    if (auth && typeof auth.onAuthStateChanged === 'function') {
      auth.onAuthStateChanged((user) => {
        if (user) {
          galleryManager.loadUserScans(user.uid);
        }
      });
    }
  }

  registerEvents() {
    // Language toggle
    const langToggle = document.getElementById('languageToggle');
    if (langToggle) {
      langToggle.addEventListener('click', () => {
        localization.toggleLanguage();
      });
    }
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
      themeToggle.addEventListener('change', (e) => {
        themeManager.setTheme(e.target.checked ? 'dark' : 'light');
      });
    }
    // Navigation tabs (top)
    document.querySelectorAll('.tab-button').forEach((tab) => {
      tab.addEventListener('click', (e) => {
        const view = e.currentTarget.dataset.view;
        this.switchView(view);
      });
    });
    // Bottom navigation
    document.querySelectorAll('.nav-item').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const view = e.currentTarget.id.replace('nav', '').toLowerCase();
        this.switchView(view);
      });
    });
    // Scan button
    const scanBtn = document.getElementById('startScanBtn');
    if (scanBtn) {
      scanBtn.addEventListener('click', () => {
        if (arScanner.isScanning) {
          arScanner.stopScan();
        } else {
          arScanner.startScan();
        }
      });
    }
  }

  switchView(viewName) {
    if (this.currentView === viewName) return;
    // Hide current view
    const currentViewEl = document.getElementById(`${this.currentView}View`);
    if (currentViewEl) currentViewEl.classList.add('hidden');
    const currentTab = document.querySelector(`.tab-button[data-view="${this.currentView}"]`);
    if (currentTab) currentTab.classList.remove('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
    // Show new view
    const newViewEl = document.getElementById(`${viewName}View`);
    if (newViewEl) newViewEl.classList.remove('hidden');
    const newTab = document.querySelector(`.tab-button[data-view="${viewName}"]`);
    if (newTab) newTab.classList.add('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
    // Update bottom navigation styles
    document.querySelectorAll('.nav-item').forEach((item) => {
      item.classList.remove('text-blue-600', 'dark:text-blue-400');
      item.classList.add('text-gray-500', 'dark:text-gray-400');
    });
    const navItem = document.getElementById(`nav${viewName.charAt(0).toUpperCase() + viewName.slice(1)}`);
    if (navItem) navItem.classList.add('text-blue-600', 'dark:text-blue-400');
    // Special handling for share view: generate a dummy QR code
    if (viewName === 'share') {
      this.generateQRCode();
    }
    this.currentView = viewName;
  }

  generateQRCode() {
    const qrSvg = document.getElementById('qrCode');
    if (!qrSvg) return;
    // Generate a simple URL incorporating the current timestamp
    const url = `https://ar-scanner.app/view/${Date.now()}`;
    // Use the global QRCode library loaded in index.html
    QRCode.toString(url, { type: 'svg' }, (err, svg) => {
      if (err) {
        console.error(err);
        return;
      }
      qrSvg.innerHTML = svg;
    });
  }
}

export const uiController = new UIController();