// Simple client‑side localization module.  It loads language files from the
// `/locales` directory and updates DOM elements annotated with the
// `data-i18n` attribute.  Languages can be toggled by calling
// localization.toggleLanguage().

class Localization {
  constructor() {
    // Determine initial language preference: stored value or browser default
    this.lang = localStorage.getItem('lang') || (navigator.language.startsWith('ar') ? 'ar' : 'en');
    this.translations = {};
    // Load the initial language
    this.loadLanguage(this.lang);
  }

  async loadLanguage(lang) {
    try {
      const response = await fetch(`/locales/${lang}.json`);
      this.translations = await response.json();
      this.lang = lang;
      localStorage.setItem('lang', lang);
      this.updateAllText();
    } catch (err) {
      console.error('Failed to load language file:', err);
    }
  }

  updateAllText() {
    // Update all elements with a data‑i18n attribute
    document.querySelectorAll('[data-i18n]').forEach((elem) => {
      const key = elem.getAttribute('data-i18n');
      const translation = this.translations[key];
      if (translation) {
        elem.innerText = translation;
      }
    });
    // Update the language toggle text
    const langButton = document.getElementById('languageText');
    if (langButton) {
      langButton.innerText = this.lang === 'ar' ? 'AR' : 'EN';
    }
    // Toggle RTL class on body for Arabic
    if (this.lang === 'ar') {
      document.body.classList.add('rtl');
    } else {
      document.body.classList.remove('rtl');
    }
  }

  toggleLanguage() {
    const newLang = this.lang === 'en' ? 'ar' : 'en';
    this.loadLanguage(newLang);
  }
}

export const localization = new Localization();