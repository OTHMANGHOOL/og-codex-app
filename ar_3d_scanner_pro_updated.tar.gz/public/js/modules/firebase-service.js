// A small wrapper around Firebase initialization.  This module attempts to
// initialise Firebase using the global compat SDK loaded in index.html.  If
// Firebase isn't available (for example when running the app offline during
// development), it falls back to a dummy implementation so that the rest of
// the application continues to work without errors.

// Firebase configuration.  Replace these values with your own project
// settings.  Without valid keys the real Firebase services won't work, but
// the dummy fallback will still allow the UI to function.
const firebaseConfig = {
  apiKey: "AIzaSyD...",
  authDomain: "ar-scanner-pro.firebaseapp.com",
  projectId: "ar-scanner-pro",
  storageBucket: "ar-scanner-pro.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abc123...",
  measurementId: "G-ABC123..."
};

let db;
let storage;
let auth;
let collection;
let addDoc;
let serverTimestamp;
let ref;
let uploadBytes;
let getDownloadURL;

try {
  // Use the compat version of Firebase that is loaded via script tags in
  // index.html.  This global variable is available as `firebase`.
  if (typeof firebase !== 'undefined') {
    const app = firebase.initializeApp(firebaseConfig);
    db = firebase.firestore();
    storage = firebase.storage();
    auth = firebase.auth();
    // Enable offline persistence for Firestore.  On the web, persistence is
    // disabled by default and must be enabled explicitly【720146111675703†L1318-L1324】.
    db.enablePersistence().catch((err) => {
      console.error('Offline persistence error:', err);
    });
    // Automatic anonymous login.  When the auth state changes and there is no
    // user, sign in anonymously【723855565617284†L1324-L1334】.
    auth.onAuthStateChanged((user) => {
      if (!user) {
        auth.signInAnonymously().catch((error) => {
          console.error('Anonymous sign‑in failed:', error);
        });
      }
    });
    // Map Firestore's collection/add APIs to functions so that other modules
    // can call them without importing Firebase directly.
    collection = (dbInstance, name) => dbInstance.collection(name);
    addDoc = (collectionRef, data) => collectionRef.add(data);
    serverTimestamp = () => firebase.firestore.FieldValue.serverTimestamp();
    // Storage helpers
    ref = (storageInstance, path) => storageInstance.ref(path);
    uploadBytes = (storageRef, blob) => storageRef.put(blob);
    getDownloadURL = (storageRef) => storageRef.getDownloadURL();
  } else {
    throw new Error('Firebase global not found');
  }
} catch (err) {
  // Fallback implementation for offline or development use.  Creates
  // in-memory mocks that satisfy the interface used by other modules.
  console.warn('Falling back to dummy Firebase services:', err);
  db = {};
  storage = {};
  // Simple dummy auth class that generates a random anonymous UID.
  class DummyAuth {
    constructor() {
      this.currentUser = { uid: 'anon-' + Math.random().toString(36).substring(2, 12) };
    }
    onAuthStateChanged(callback) {
      callback(this.currentUser);
    }
    signInAnonymously() {
      return Promise.resolve({ user: this.currentUser });
    }
  }
  auth = new DummyAuth();
  collection = () => null;
  addDoc = () => Promise.resolve();
  serverTimestamp = () => new Date();
  ref = () => null;
  uploadBytes = () => Promise.resolve();
  getDownloadURL = () => Promise.resolve('');
}

export {
  db,
  storage,
  auth,
  collection,
  addDoc,
  serverTimestamp,
  ref,
  uploadBytes,
  getDownloadURL
};